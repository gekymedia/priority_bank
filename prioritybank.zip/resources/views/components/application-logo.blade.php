<a href="{{ url('/') }}">
    <img src="{{ asset('pbg_logo.png') }}" alt="Priority Bank Ghana Logo" class="w-20 h-20 mx-auto">
</a>
